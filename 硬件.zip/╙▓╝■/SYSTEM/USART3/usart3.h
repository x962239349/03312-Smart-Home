#ifndef __USART3_H
#define __USART3_H	 
#include "sys.h"

void USART3_Init(void);//��ʼ��

		 				    
#endif
